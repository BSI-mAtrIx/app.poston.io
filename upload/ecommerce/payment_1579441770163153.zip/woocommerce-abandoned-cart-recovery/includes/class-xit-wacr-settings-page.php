<?php 

/**
  * WooCommerce Abandoned Cart Recovery Setup
  *
  * @since 1.0.0
  */

class Xit_Wacr_Settings_Page {
    
    /**
     * Contains failed product list table object
     */ 
    private $error_log;
    
    /**
     * Holds all the options
     */ 
    private $options;
    
    /**
     * Constructor
     */
    public function __construct() {
        // Registers options
        add_action( 'admin_init', [ $this, 'on_admin_init' ] );
        
        // Registers a menu
        add_action( 'admin_menu', [ $this, 'on_admin_menu' ] );
        add_filter( 'set-screen-option', [ $this, 'on_set_screen' ], 10, 3 );
    }
    
    public function on_set_screen( $status, $option, $value ) {
        echo $option;
    	return $value;
    }    
    
    /**
     * Adds a new menu and submenu in the admin dashboard
     */ 
    public function on_admin_menu() {
    	$hook = add_menu_page(
    		__( 'Error Logs', 'xit_wacr' ),
    		__( 'Error Logs', 'xit_wacr' ),
    		'manage_options',
    		'xit_wacr_logs',
    		[ $this, 'cart_error_log' ],
    		'dashicons-dismiss'
    	);
    	
    	// Adds submenu
    	add_submenu_page(
    	    'xit_wacr_logs',
    		__( 'WooCommerce abandoned cart recovery settings', 'xit_wacr' ),
    		__( 'Settings', 'xit_wacr' ),
    		'manage_options',
    		'xit_wacr_settings',
    		[ $this, 'abandoned_cart_settings' ]
    	);
    
    	add_action( "load-$hook", [ $this, 'on_set_screen_option' ] );
    }
    
    /**
     * Sets screen option for the failed product list
     */ 
    public function on_set_screen_option() {
    
    	$option = 'per_page';
    	$args   = [
    		'label'   => __( 'Logs per page', 'xit_wacr' ),
    		'default' => 10,
    		'option'  => 'wacr_error_log_per_page'
    	];
    
    	add_screen_option( $option, $args );
    	
        require_once dirname( XIT_WACR_PLUGIN_FILE ) . '/includes/class-xit-wacr-error-log-list.php';
        
        // Creates an instance of Xit_Wacr_Error_Log_List
        $this->error_log = new Xit_Wacr_Error_Log_List();    	
    }
    
    /**
     * The main method for displaying list of logs
     */ 
    public function cart_error_log() {
        
    	?>
    	<div class="wrap">
    		<h2><?php _e( 'Error Logs', 'xit_wacr' ); ?></h2>
    		<div id="poststuff">
				<form method="post">
					<?php
					    $this->error_log->prepare_items();
					    $this->error_log->display(); 
					?>
				</form>
    			<div class="clear"></div>
    		</div>
    	</div>
    <?php
    
    }
    
    /**
     * Creates options page
     */ 
    public function abandoned_cart_settings() {
        // Fills in options 
        $this->options = get_option( 'xit_wacr_abandoned_cart_options' );
        
        ?>
        <div class="wrap">
            <h2><?php _e( 'WooCommerce Abandoned Cart Recovery', 'xit_wacr' ); ?></h2>
            <form method="post" action="options.php">
            <?php
                settings_errors();
                settings_fields( 'xit_wacr_abandoned_cart_group' );
                do_settings_sections( 'xit_wacr_abandoned_cart_settings' );
                submit_button();
            ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Sets up settings
     */ 
    public function on_admin_init() {
        
        // Registers settings
        register_setting(
            'xit_wacr_abandoned_cart_group',
            'xit_wacr_abandoned_cart_options',
            [ $this, 'sanitize' ]
        );
        
        add_settings_section(
            'xit_wacr_setting_section_id',
            __( 'Settings', 'xit_wacr' ),
            [ $this, 'print_section_info' ],
            'xit_wacr_abandoned_cart_settings'
        );        
        
        // Adds verification ID
        add_settings_field(
            'xit_wacr_api_key',
            __( 'API Key', 'xit_wacr' ),
            [ $this, 'api_key_field' ],
            'xit_wacr_abandoned_cart_settings',
            'xit_wacr_setting_section_id'
        ); 
        
        // Adds server URL
        add_settings_field(
            'xit_wacr_server_url',
            __( 'Server URL', 'xit_wacr' ),
            [ $this, 'server_url_field' ],
            'xit_wacr_abandoned_cart_settings',
            'xit_wacr_setting_section_id'
        );
        
        // Add checkbox message
        add_settings_field(
            'xit_wacr_checkbox_msg',
            __( 'Error Message', 'xit_wacr' ),
            [ $this, 'checkbox_message_field' ],
            'xit_wacr_abandoned_cart_settings',
            'xit_wacr_setting_section_id'
        );
    }
    
    public function print_section_info() {
        echo '';
    }
    
    public function api_key_field() {
        printf(
          '<input type="text" id="xit_wacr_api_key" class="regular-text" name="xit_wacr_abandoned_cart_options[xit_wacr_api_key]" value="%1s" /><p class="description" id="tagline-description">%2s</p>',
          isset( $this->options['xit_wacr_api_key'] ) ? esc_attr( $this->options['xit_wacr_api_key'] ) : '',
          __( 'The API key that has been provided you.', 'xit_wacr' )
        );
    }    
    
    public function server_url_field() {
        printf(
            '<input type="text" id="xit_wacr_server_url" class="regular-text" name="xit_wacr_abandoned_cart_options[xit_wacr_server_url]" value="%s" /><p class="description" id="tagline-description">%2s</p>',
            isset( $this->options['xit_wacr_server_url'] ) ? esc_attr( $this->options['xit_wacr_server_url'] ) : '',
          __( 'The URL where cart data will be submitted.', 'xit_wacr' )
        );
    }    
    
    public function checkbox_message_field() {
        printf(
            '<input type="text" id="xit_wacr_checkbox_msg" class="regular-text" name="xit_wacr_abandoned_cart_options[xit_wacr_checkbox_msg]" value="%s" /><p class="description" id="tagline-description">%2s</p>',
            isset($this->options['xit_wacr_checkbox_msg']) ? esc_attr( $this->options['xit_wacr_checkbox_msg'] ) : '',
          __( 'The error message to be shown if checkbox is not checked.', 'xit_wacr' )
        );
    }
    
    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        
        if( isset( $input['xit_wacr_api_key'] ) ) {
            $new_input['xit_wacr_api_key'] = sanitize_key( $input['xit_wacr_api_key'] );
        }

        if( isset( $input['xit_wacr_server_url'] ) ) {
            $new_input['xit_wacr_server_url'] = esc_url_raw( $input['xit_wacr_server_url'] );
        }        
        
        if( isset( $input['xit_wacr_checkbox_msg'] ) ) {
            $new_input['xit_wacr_checkbox_msg'] = sanitize_text_field( $input['xit_wacr_checkbox_msg'] );
        }

        return $new_input;
    }    
}