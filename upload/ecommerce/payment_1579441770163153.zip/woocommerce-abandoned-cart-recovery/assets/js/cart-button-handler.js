(function( window, $ ) {
    
    $(document).ready(function() {
        
        // Submit button    
        var button = $('.single_add_to_cart_button'),
            unchecked_msg = $('#xit-unchecked-car-button-message');
           
        // Checks if the FB checkbox is checked
        button.on('click', function(e) {
            e.preventDefault();
    
            if (window.myCheckBoxState_01 === 'checked') {
                $(this).unbind('click');
                $(this).trigger('click');
                unchecked_msg.hide();
            } 
            
            if (window.myCheckBoxState_01 === 'unchecked') {
                e.preventDefault();
                unchecked_msg.show();
            }
        });
        
        // Triggers click event on skipping FB checkbox
        $('#xit-skip-fb-checkbox').on('click', function() {
            button.unbind('click');
            button.trigger('click');
        });
   
    });
    
})( window, jQuery );
    


